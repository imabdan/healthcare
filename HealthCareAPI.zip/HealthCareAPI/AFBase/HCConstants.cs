﻿namespace HealthCareAPI.AFBase
{
    public static class HCConstants
    {
        public const string CommonSchema = "Common";
        public const string TransactionSchema = "Transaction";
        public const string SecretSchema = "Secret";
    }
}
