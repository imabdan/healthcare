﻿using HealthCareAPI.AFBase;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace HealthCareAPI.Framework
{
    public class AuditableBase
    {
        public int? UpdatedBy { get; set; }
        [Column(TypeName = "timestamp without time zone")]
        public DateTime? UpdatedDate { get; set; }
        [Required]
        public Guid? UniqueId { get; set; } = Guid.NewGuid();
        [JsonConverter(typeof(JsonStringEnumConverter))]
        [Column(TypeName = "varchar")]
        [Required]
        public AFStatus ActiveStatus { get; set; } = AFStatus.A;
    }

    public class TranAuditableBase : AuditableBase
    {
        public int CreatedBy { get; set; }
        [Column(TypeName = "timestamp without time zone")]
        public DateTime CreatedDate { get; set; }
    }
}
