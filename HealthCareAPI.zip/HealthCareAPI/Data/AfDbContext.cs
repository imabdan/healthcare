﻿using HealthCare.Models;
using HealthCareAPI.AFBase;
using HealthCareAPI.Area.Common;
using HealthCareAPI.Area.Transaction;
using HealthCareAPI.Transactions;
using Microsoft.EntityFrameworkCore;

namespace HealthCare.Data
{
    public class AfDbContext : DbContext
    {
        public AfDbContext(DbContextOptions<AfDbContext> options) : base(options)
        {
            
        }

        public DbSet<UserMaster> Users {  get; set; }
        public DbSet<RefreshToken> RefreshTokens {  get; set; }
        public DbSet<Appointment> Appointments {  get; set; }
        public DbSet<veAppointment> veAppointment {  get; set; }
        public DbSet<Prescription> Prescriptions {  get; set; }
        public DbSet<PrescriptionMedicine> Medicines {  get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Mapping tables with schema
            modelBuilder.Entity<UserMaster>().ToTable(nameof(UserMaster), schema: HCConstants.CommonSchema);
            modelBuilder.Entity<RefreshToken>().ToTable(nameof(RefreshToken), schema: HCConstants.SecretSchema);
            modelBuilder.Entity<Appointment>().ToTable(nameof(Appointment), schema: HCConstants.TransactionSchema);
            modelBuilder.Entity<veAppointment>().ToTable(nameof(veAppointment), schema: HCConstants.TransactionSchema);
            modelBuilder.Entity<PrescriptionMedicine>().ToTable(nameof(PrescriptionMedicine), schema: HCConstants.TransactionSchema);
            // Prescription table
            modelBuilder.Entity<Prescription>(entity =>
            {
                entity.ToTable(nameof(Prescription), schema: HCConstants.TransactionSchema);
                entity.HasKey(p => p.Id);
            });

            // PrescriptionMedicine table
            modelBuilder.Entity<PrescriptionMedicine>(entity =>
            {
                entity.ToTable(nameof(PrescriptionMedicine), schema : HCConstants.TransactionSchema);
                entity.HasKey(pm => pm.Id);

                // Relation
                entity.HasOne(pm => pm.Prescription)
                      .WithMany(p => p.Medicines)
                      .HasForeignKey(pm => pm.PrescriptionId)
                      .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}
