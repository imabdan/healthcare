using AutoMapper;
using HealthCare.Data;
using HealthCare.Services;
using HealthCareAPI.Framework;
using HealthCareAPI.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Text.Json.Serialization;

namespace HealthCare
{
    public class Program
    {
    
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddScoped<IUserRepo, UserService>();
            builder.Services.AddScoped<IAppointmentRepo, AppointmentService>();
            builder.Services.AddSingleton<TokenService>();


            // JWT key (for show and tell - move to secrets or env in prod)
            var key = builder.Configuration["Jwt:Key"] ?? "afhealthcare_show_and_tell_project";
            var keyBytes = Encoding.UTF8.GetBytes(key);

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(opt =>
            {
                opt.RequireHttpsMetadata = false; // set true in prod
                opt.SaveToken = true;
                opt.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(keyBytes),
                    ClockSkew = TimeSpan.Zero
                };
            });

            builder.Services.AddControllers(option =>
            {
                option.ReturnHttpNotAcceptable = true;//will accept only json
            })
            .AddXmlSerializerFormatters()//Can allow Xml
            .AddJsonOptions(jop =>
            {
                jop.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());//For enum converter like for Patient instead of 0, it will return PT
            });

            builder.Services.AddDbContext<AfDbContext>(options =>
            {
                options.UseNpgsql(
                    builder.Configuration.GetConnectionString("locConnectionStr")
                );
            });

            builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddCors(cors =>
            {
                cors.AddPolicy("AngularDev", p =>
                {
                    p.WithOrigins("http://localhost:4200")
                     .AllowAnyHeader()
                     .AllowAnyMethod()
                     .AllowCredentials();
                });
            });
            var app = builder.Build();
            app.UseMiddleware<ExceptionMiddleware>();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCors("AngularDev");

            app.UseAuthorization();

            app.MapControllers();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.UseSwagger();
            app.UseSwaggerUI();

            app.Run();

        }
    }
}
