﻿using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace CryptoGraphy
{
    /// <summary>
    /// Class to handle all the Security needs of the HealthCare Application. this class made static to avoid object creation and allow direct access
    /// </summary>
    public static class HealthCareCryptoGraphy
    {
        /// <summary>
        /// Method to hash the given password. A Random Generated Salt would be created for every hash. This would be appended and 
        /// stored within the hash itself
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        public static string HashPassword(string password)
        {
            //A salt is a random value added to a password before hashing it.
            byte[] salt = new byte[128 / 8];
            //Compute the Salt Value
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }
            string saltVal = Convert.ToBase64String(salt);

            // Derive a 256-bit secure hash (subkey) from the given password using PBKDF2.
            // PBKDF2 = Password-Based Key Derivation Function 2.
            // It applies HMACSHA1 hashing 10,000 times to make brute-force attacks much harder.

            string hashed = Convert.ToBase64String(
                KeyDerivation.Pbkdf2(
                    password: password,          // The user-entered password
                    salt: salt,                  // A random salt to ensure unique hashes
                    prf: KeyDerivationPrf.HMACSHA1, // Pseudorandom function used internally (HMACSHA1)
                    iterationCount: 10000,       // Number of hashing rounds (higher = slower but more secure)
                    numBytesRequested: 256 / 8   // Final hash length: 256 bits → 32 bytes
                )
            );

            //Return the Hash along with the salt
            return saltVal + hashed;
        }

        /// <summary>
        /// Method to check if the Given password matches the stored hash value.
        /// </summary>
        /// <param name="password"></param>
        /// <param name="hashedPassword"></param>
        /// <returns></returns>
        public static bool CheckPassword(string password, string hashedPassword)
        {
            //Retrieve the Salt Value which we added while hashing
            string saltVal = hashedPassword.Substring(0, 24);
            //Retrieve the Hash Value
            string hashVal = hashedPassword.Substring(24);

            //Compute the new Hash
            byte[] salt = Convert.FromBase64String(saltVal);
            string newHash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA1,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
            //Return the Comparison result
            return ByteArraysEqual(Convert.FromBase64String(hashVal), Convert.FromBase64String(newHash));
        }

        /// <summary>
        /// Method to Compare two hashes byte by byte
        /// </summary>
        /// <param name="a"></param>
        /// <param name="f"></param>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
        private static bool ByteArraysEqual(byte[] a, byte[] f)
        {
            if (a == null && f == null)
            {
                return true;
            }
            if (a == null || f == null || a.Length != f.Length)
            {
                return false;
            }
            var areSame = true;
            for (var i = 0; i < a.Length; i++)
            {
                areSame &= (a[i] == f[i]);
            }
            return areSame;
        }
    }
}
