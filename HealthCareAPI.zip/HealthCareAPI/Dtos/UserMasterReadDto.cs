﻿namespace HealthCare.Dtos
{
    public class UserMasterReadDto
    {
        public string Name { get; set; }
        public string BloodGroup { get; set; }
        public string Specialization { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string PhoneNumber { get; set; }
    }
}
