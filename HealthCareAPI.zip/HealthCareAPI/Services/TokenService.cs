using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using HealthCare.Models;
using HealthCareAPI.Area.Common;

namespace HealthCare.Services;

public class TokenService
{
    private readonly IConfiguration _cfg;
    public TokenService(IConfiguration cfg) => _cfg = cfg;

    public string GenerateAccessToken(UserMaster user)
    {
        //Getting the secret key added in the appsettings
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_cfg["Jwt:Key"]!));
        //Creating signing credential with encoded secret key with hmacSha256 algorithm, this will be used to verify that token wasn't changed
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        //Claim using user data
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.UserMasterId.ToString()),
            new Claim(JwtRegisteredClaimNames.Email, user.Email)
        };

        //Token object with claims, expiry time and credential
        //Here issuer and audience also can be include
        var token = new JwtSecurityToken(
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(2),
            signingCredentials: creds);

        //Finally write the token and return
        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    /// <summary>
    /// Method to generate a refresh token with userId and expiry dates
    /// </summary>
    /// <param name="userId"></param>
    /// <param name="days"></param>
    /// <returns></returns>
    public RefreshToken GenerateRefreshToken(int userId, int days = 7)
    {
        var randomBytes = RandomNumberGenerator.GetBytes(64);
        var token = Convert.ToBase64String(randomBytes);

        return new RefreshToken
        {
            Token = token,
            UserMasterId = userId,
            ExpiresAt = DateTime.UtcNow.AddDays(days),
            IsRevoked = false
        };
    }
}
