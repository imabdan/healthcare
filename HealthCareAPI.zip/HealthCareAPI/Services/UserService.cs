using Microsoft.EntityFrameworkCore;
using HealthCare.Data;
using CryptoGraphy;
using HealthCareAPI.AFBase;
using HealthCareAPI.Framework;
using HealthCareAPI.Dtos;
using HealthCareAPI.Area.Common;

namespace HealthCare.Services;

public class UserService : IUserRepo
{
    private readonly AfDbContext _afDbContext;
    public UserService(AfDbContext db) => _afDbContext = db;

    /// <summary>
    /// Method to validate user whether exist or not, if exist then whether entered password is correct or not
    /// </summary>
    /// <param name="email"></param>
    /// <param name="password"></param>
    /// <returns></returns>
    public async Task<UserMaster> ValidateCredentialsAsync(string email, string password)
    {
        //Getting the user record based on the entered email, it will return  single or null object bcoz email is unique and active
        var userRecord = await _afDbContext.Users.FirstOrDefaultAsync(af => af.Email == email && af.ActiveStatus == AFStatus.A);
        if (userRecord == null)
            return null;
        //Check entered password (we're haching again ): ) is matching or not with stored hash password
        //If not return null user
        if (!HealthCareCryptoGraphy.CheckPassword(password, userRecord?.PasswordHash))
        {
            userRecord = null;
        }
        return userRecord;

    }


    /// <summary>
    /// Method to get single active user by id
    /// </summary>
    /// <param name="id"></param>
    /// <returns></returns>
    Task<List<UserMaster>> IBaseRepository<UserMaster>.GetAllAsync()
    {
        return _afDbContext.Users.Where(af => af.ActiveStatus == AFStatus.A).ToListAsync();
    }

    /// <summary>
    /// Method to get list of available and active users 
    /// </summary>
    /// <returns></returns>
    public Task<UserMaster> GetbyIdAsync(int id)
    {
        return _afDbContext.Users.FirstOrDefaultAsync(af => af.UserMasterId == id && af.ActiveStatus == AFStatus.A);
    }


    /// <summary>
    /// Method to create user with entered details and password hash
    /// </summary>
    /// <param name="entity"></param>
    /// <returns></returns>
    public UserMaster Create(UserMaster entity)
    {
        //Used transaction for commit, rollback in case of related transaction
        using (var tran = _afDbContext.Database.BeginTransaction()) 
        {
            try
            {
                //Instead of storing plain password, store hash pswd for security concern
                entity.PasswordHash = HealthCareCryptoGraphy.HashPassword(entity.Password);
                _afDbContext.Users.Add(entity);
                _afDbContext.SaveChanges();
                tran.Commit();
            }
            catch (Exception ex) 
            {
               tran.Rollback();
            }
      
        }
        return entity;
    }
    /// <summary>
    /// Method to update user data
    /// </summary>
    /// <param name="entity"></param>
    /// <returns></returns>
    /// <exception cref="NotImplementedException"></exception>
    public UserMaster Update(UserMaster entity)
    {
        _afDbContext.Users.Update(entity);
        _afDbContext.SaveChanges();
        return entity;
    }

    /// <summary>
    /// Method to delete user by id
    /// </summary>
    /// <param name="id"></param>
    public void Delete(int id)
    {
        var entity = _afDbContext.Users.FirstOrDefault(af => af.UserMasterId == id);
        _afDbContext.Remove(entity);
        _afDbContext.SaveChanges();
    }
    /// <summary>
    /// Mehtod to check duplicate email
    /// </summary>
    /// <param name="email"></param>
    /// <returns></returns>
    public async Task<bool> EmailDupCheck(string email)
    {
        //Check any duplicate active email exist
        return await _afDbContext.Users.AnyAsync(af => af.Email == email && af.ActiveStatus == AFStatus.A);
    }
    /// <summary>
    /// Method to get active physican list for the dropdown data source
    /// </summary>
    /// <returns></returns>
    public async Task<List<PhysicianDto>> GetPhysicians()
    {
        return await _afDbContext.Users.Where(af => af.Role == Role.PH && af.ActiveStatus == AFStatus.A).Select(fu => new PhysicianDto
        {
            Name = fu.FirstName + " " + fu.LastName,
            UserMasterId = fu.UserMasterId
        }).ToListAsync();
    }
}
