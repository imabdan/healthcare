﻿using HealthCareAPI.Framework;
using System.ComponentModel.DataAnnotations;

namespace HealthCareAPI.Area.Transaction
{
    public class AppointmentBase : TranAuditableBase
    {
        [Key]
        public int AppointmentId { get; set; }
        public int UserMasterId { get; set; }
        public int PhysicianId { get; set; }
        public DateOnly AppointmentDate { get; set; }
        public TimeSpan AppointmentTime { get; set; }
        public string Disease { get; set; }
        public string Details { get; set; }
        public string Status { get; set; }
    }
    public class Appointment : AppointmentBase
    {

    }
    /// <summary>
    /// Class to hold some related data e.g data from other table
    /// </summary>
    public class veAppointment : AppointmentBase
    {
        public string PhysicianName { get; set; }
        public string PatientName { get; set; }
    }
}

