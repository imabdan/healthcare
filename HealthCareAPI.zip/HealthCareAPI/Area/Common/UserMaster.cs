using HealthCareAPI.AFBase;
using HealthCareAPI.Framework;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace HealthCareAPI.Area.Common;

public class UserMaster : AuditableBase
{
    [Key]
    public int UserMasterId { get; set; }
    [Required]
    public string Email { get; set; }
    [Required]
    public string FirstName { get; set; }
    [Required]
    public string LastName { get; set; }
    [Required]
    public string PhoneNumber { get; set; }//Kept string so it can store leading 0,and + etc
    public string EmergencyContact { get; set; }
    [Required]
    public DateOnly DOB { get; set; }
    [Required]
    public string Address { get; set; }
    [Required]
    public string State { get; set; }//Instead we can store StateId from StateMaster - but for show n tell storing directly state name
    [Required]
    public string PostalCode { get; set; } //Instead we can store Id from Master
    [Required]
    public string Country { get; set; } //Instead we can store Id from Master
    [JsonConverter(typeof(JsonStringEnumConverter))]
    [Column(TypeName = "varchar")]
    [Required]
    public Role Role { get; set; }
    public string PasswordHash { get; set; }
    public string BloodGroup { get; set; }
    public string Gender { get; set; }
    public string Specialization { get; set; }
    [NotMapped]
    public string Password { get; set; }
}
