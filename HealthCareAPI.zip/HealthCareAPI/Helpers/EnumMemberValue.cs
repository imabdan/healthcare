﻿using System.Runtime.Serialization;

namespace HealthCareAPI.Helpers
{
    public static class EnumMemberValue
    {
        //To check
        public static string GetEnumMemberValue(Enum enumValue)
        {
            var type = enumValue.GetType();
            var info = type.GetField(enumValue.ToString());
            var attribute = info.GetCustomAttributes(typeof(EnumMemberAttribute), false)
                                .FirstOrDefault() as EnumMemberAttribute;
            return attribute?.Value ?? enumValue.ToString();
        }
    }
}
