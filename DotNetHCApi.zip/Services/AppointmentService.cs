﻿using HealthCare.Data;
using HealthCareAPI.AFBase;
using HealthCareAPI.Area.Transaction;
using HealthCareAPI.Framework;
using HealthCareAPI.Helpers;
using HealthCareAPI.Transactions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace HealthCareAPI.Services
{
    public class AppointmentService : IAppointmentRepo
    {
        private readonly AfDbContext _afDb;

        public AppointmentService(AfDbContext afDbContext)
        {
            this._afDb = afDbContext;
        }
        public Appointment Create(Appointment entity)
        {
            entity.CreatedBy = entity.UserMasterId; 
            entity.CreatedDate = DateTime.Now;
            _afDb.Appointments.Add(entity);
            _afDb.SaveChanges();
            return entity;
        }

        public void Delete(int id)
        {
            _afDb.Appointments.Where(af => af.AppointmentId == id).ExecuteDelete();
        }

        public async Task<List<Appointment>> GetAllAsync()
        {
            return await _afDb.Appointments.ToListAsync();
        }
        /// <summary>
        /// Method to get list of appointment with patient details to show in dashboards
        /// </summary>
        /// <param name="id"></param>
        /// <param name="role"></param>
        /// <returns></returns>
        public async Task<List<veAppointment>> GetAllbyIdAsync(int id, string role)
        {
            //Getting all the appointment history for patient and physician based on role
            
            if(role == EnumMemberValue.GetEnumMemberValue(Role.PH))
            {
                return await _afDb.veAppointment.Where(af => af.PhysicianId == id).OrderBy(re => re.AppointmentDate).ThenBy(en => en.AppointmentTime).ToListAsync();
            }
            return await _afDb.veAppointment.Where(af => af.UserMasterId == id).OrderBy(re => re.AppointmentDate).ThenBy(en => en.AppointmentTime).ToListAsync();
        }

        public async Task<Appointment> GetbyIdAsync(int id)
        {
            return await _afDb.Appointments.FirstOrDefaultAsync(af => af.AppointmentId == id);
        }
        /// <summary>
        /// Method to update appointment
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public Appointment Update(Appointment entity)
        {
            _afDb.Appointments.Update(entity);
            _afDb.SaveChanges();
            return entity;
        }
        /// <summary>
        /// Method to save prescription for an appointment
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public async Task<Prescription> SavePresAsync(PrescriptionCreateDto dto)
        {
            var prescription = new Prescription
            {
                AppointmentId = dto.AppointmentId,
                PatientId = dto.PatientId,
                Symptoms = dto.Symptoms,
                Diagnosis = dto.Diagnosis,
                Advice = dto.Advice,
                NextVisit = dto.NextVisit,
                CreatedBy = 6,
                CreatedDate = DateTime.Now,
                Medicines = dto.Medicines.Select(m => new PrescriptionMedicine
                {
                    Name = m.Name,
                    Dosage = m.Dosage,
                    Duration = m.Duration,
                    CreatedBy = 6,
                    CreatedDate = DateTime.Now,
                }).ToList()
            };

            _afDb.Prescriptions.Add(prescription);
            await _afDb.SaveChangesAsync();

            return prescription;
        }


        public async Task<List<PrescriptionMedicine>> GetPres(int appointmentId)
        {
            var prescId = _afDb.Prescriptions.Where(af => af.AppointmentId == appointmentId).FirstOrDefault()?.Id;
            var result = await _afDb.Medicines.Where(af => af.PrescriptionId == prescId).ToListAsync();
            return result;
        }

    }
}
