using HealthCareAPI.Area.Common;

namespace HealthCare.Models;

public class RefreshToken
{
    public int RefreshTokenId { get; set; }
    public string Token { get; set; } = default!;
    public int UserMasterId { get; set; }
    public DateTime ExpiresAt { get; set; }
    public bool IsRevoked { get; set; }
    public string ReplacedBy { get; set; }
    public UserMaster User { get; set; }
}
