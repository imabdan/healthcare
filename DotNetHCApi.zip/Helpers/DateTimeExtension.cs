﻿namespace HealthCare.Helpers
{
    public static class DateTimeExtension
    {
        public static int GetCurrentAge(this DateOnly date) 
        {
            var currDate = DateOnly.FromDateTime(DateTime.UtcNow);
            int age = currDate.Year - date.Year;//25
            if (currDate < date.AddYears(age)) 
            {
                age--;
            }
            return age;
        }
    }
}
