﻿using AutoMapper;
using HealthCareAPI.Area.Transaction;
using HealthCareAPI.Framework;
using HealthCareAPI.Profiles;
using HealthCareAPI.Transactions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthCareAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AppointmentController : ControllerBase
    {
        private readonly IAppointmentRepo _appointmentRepo;
        private readonly IMapper _mapper;
        public AppointmentController(IAppointmentRepo appointmentRepo, IMapper mapper)
        {
            this._appointmentRepo = appointmentRepo;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<Appointment> getAppointment(int id)
        {
            return await _appointmentRepo.GetbyIdAsync(id);
        }

        [HttpGet("{id}/appointments")]
        public async Task<IActionResult> GetAppointmentsAsync(int id, string role)
        {
            var entity = await _appointmentRepo.GetAllbyIdAsync(id, role);

            if (entity == null)
                return NotFound();

            return Ok(entity);
        }

        [HttpPost]
        public IActionResult CreateAppointment([FromBody] Appointment entity)
        {
            try
            {
                var created = _appointmentRepo.Create(entity);
                if (created == null)
                    return BadRequest(new { message = "Failed to create appointment." });

                return StatusCode(201, created);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Internal server error.", error = ex.Message });
            }
        }


        [HttpPost("savePresc")]
        public async Task<IActionResult> Save([FromBody] PrescriptionCreateDto dto)
        {
            var appt = await _appointmentRepo.GetbyIdAsync(dto.AppointmentId);

            if (appt == null)
                return NotFound("Appointment not found");

            await _appointmentRepo.SavePresAsync(dto);

            return Ok("Prescription stored successfully");
        }


        [HttpGet("getPresc")]
        public async Task<IActionResult> GetPrescription(int prescId)
        {
            var presMedicine = await _appointmentRepo.GetPres(prescId);
            return Ok(_mapper.Map<List<MedicineDto>>(presMedicine));
        }
    }
}
