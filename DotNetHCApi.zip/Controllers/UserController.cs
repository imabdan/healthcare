using AutoMapper;
using HealthCare.Dtos;
using HealthCareAPI.Area.Common;
using HealthCareAPI.Framework;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HealthCare.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class UserController : ControllerBase
{
    private readonly IUserRepo _userRepository;
    private readonly IMapper _mapper;

    public UserController(IUserRepo userRepository, IMapper mapper)
    {
        _userRepository = userRepository;
        _mapper = mapper;
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUserAsync(int id)
    {
        var results =  await _userRepository.GetbyIdAsync(id);
        if (results == null) 
            return NotFound();

        //Use of DTO using IMapper
        return Ok(_mapper.Map<UserMasterReadDto>(results));
    }

    [HttpGet]
    public async Task<List<UserMaster>> GetAllUsersAsync()
    {
        return await _userRepository.GetAllAsync();
    }

    [AllowAnonymous]
    [HttpPost("register")]
    public UserMaster RegisterUser([FromBody] UserMaster user)
    {
        return _userRepository.Create(user);
    }


    [HttpGet("check-email")]
    public async Task<IActionResult> CheckDuplicateEmail(string email)
    {
        bool exists = await _userRepository.EmailDupCheck(email);
        return Ok(new { exists });
    }

    [HttpGet("physicians")]
    public async Task<IActionResult> GetPhysicianList()
    {
        var result = await _userRepository.GetPhysicians();
        if (result == null) return NotFound();

        return Ok(result);
    }

}
