using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HealthCare.Data;
using HealthCare.Models;
using HealthCare.Services;
using System.Diagnostics.CodeAnalysis;
using HealthCareAPI.Helpers;
using HealthCareAPI.Framework;

namespace HealthCare.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IUserRepo _userService;
    private readonly TokenService _tokenService;
    private readonly AfDbContext _afDbContext;

    public AuthController(IUserRepo userService, TokenService tokenService, AfDbContext db)
    {
        _userService = userService;
        _tokenService = tokenService;
        _afDbContext = db;
    }

    /// <summary>
    /// Method to check login credentials, create access token and refresh token
    /// </summary>
    /// <param name="req"></param>
    /// <returns></returns>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        #region User Authentication
        //Validate user
        var user = await _userService.ValidateCredentialsAsync(req.Email, req.Password);
        //if not found means either doesn't exist or not active, return unauthorized
        if (user == null) return Unauthorized("Invalid credentials or User has been blocked or suspended");
        #endregion

        #region TOken Generation
        //If it is a valid user then generate the access token using user details
        var accessToken = _tokenService.GenerateAccessToken(user);
        //Parallely generate the refresh token, if access token is expired, refresh token can be used to generate new acces token
        var refreshToken = _tokenService.GenerateRefreshToken(user.UserMasterId);
        #endregion

        #region Refresh Token Insertion
        //Insert refresh toke againts the user
        _afDbContext.RefreshTokens.Add(refreshToken);
        await _afDbContext.SaveChangesAsync();

        //Add refresh toke http-only cookie, it will be used to generate a new access token if it is expired
        Response.Cookies.Append("refreshToken", refreshToken.Token, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = refreshToken.ExpiresAt,//will expire in given date
            Path = "/"
        });
        #endregion
        return Ok(new 
        { 
            token = accessToken, 
            user =  new 
            { 
                user.UserMasterId, 
                user.Email, 
                Role = EnumMemberValue.GetEnumMemberValue(user.Role),//Converts enum to it's actual value eg: Physician,Patient
                Name = $"{user.FirstName} {user.LastName}"
            } 
        });
    }

    /// <summary>
    /// Method to generate a refresh token, when access token is expired, to get a new access token
    /// </summary>
    /// <returns></returns>
    [HttpPost("refresh")]
    public async Task<IActionResult> Refresh()
    {
        #region Refresh Token Check
        //Get refresh token from cookie, which was stored while login
        var rt = Request.Cookies["refreshToken"];

        //Delete existing refresh token
        Response.Cookies.Delete("refreshToken", new CookieOptions
        {
            Path = "/",          
            Secure = true,
            SameSite = SameSiteMode.None
        });

        //Unauthorized if refresh token not found due to xyz reasons, eg logput
        if (string.IsNullOrEmpty(rt)) return Unauthorized();

        //Get the refresh token from db, which was stored while login to match the coming and stored and to check the expiration and revokation (:
        var stored = await _afDbContext.RefreshTokens.Include(af => af.User)
                                            .FirstOrDefaultAsync(fu => fu.Token == rt);

        //If refresh roken is null, or revoked while logout or geneating a new rt
        if (stored == null || stored.IsRevoked || stored.ExpiresAt <= DateTime.UtcNow)
            return Unauthorized();

        // rotate refresh token
        stored.IsRevoked = true;
        #endregion

        #region New Refresh Token Generation
        //Generate a new refresh token and save it to db
        var newRefresh = _tokenService.GenerateRefreshToken(stored.UserMasterId);
        //Note : THis is not correct way, communicating with db directly from controller - we can have one more layer as authBO class, but for show n tell its fine
        _afDbContext.RefreshTokens.Add(newRefresh);
        await _afDbContext.SaveChangesAsync();

        //Add new generated rt to the http only cookie
        Response.Cookies.Append("refreshToken", newRefresh.Token, new CookieOptions
        {
            HttpOnly = true,
            Secure = true,
            SameSite = SameSiteMode.None,
            Expires = newRefresh.ExpiresAt,
            Path = "/"
        });
        #endregion

        #region New Access Token on Refresh
        //Now after refresh token check validation done, generating a new access token which can be used for later requests
        var newAccess = _tokenService.GenerateAccessToken(stored?.User!);
        #endregion

        return Ok(new { token = newAccess });
    }

    /// <summary>
    /// Method to process logout logic
    /// </summary>
    /// <returns></returns>
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        #region Refresh Token Revoke Process
        //Get refresh token from cookie, which was stored while login or refresh token generation
        var rt = Request.Cookies["refreshToken"];
        if (!string.IsNullOrEmpty(rt))
        {
            //Check in the db whether exists or not
            var stored = await _afDbContext.RefreshTokens.FirstOrDefaultAsync(x => x.Token == rt);
            if (stored != null)
            {
                //Mark as revoked so it cannot be used later
                stored.IsRevoked = true;
                await _afDbContext.SaveChangesAsync();
            }
        }
        #endregion

        #region Refresh Token Clearing Process in Cookie
        //In cookie clear the refresh token and expiry mark as earlier than today date, for the hard check, so it cannot be used anyway
        Response.Cookies.Append("refreshToken", "", new CookieOptions
        {
            HttpOnly = true,
            Secure = false,
            SameSite = SameSiteMode.Strict,
            Expires = DateTime.UtcNow.AddDays(-1)
        });
        #endregion

        return Ok();
    }
}
