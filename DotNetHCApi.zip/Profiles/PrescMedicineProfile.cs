﻿using AutoMapper;
using HealthCareAPI.Transactions;

namespace HealthCareAPI.Profiles
{
    public class PrescMedicineProfile : Profile
    {
        public PrescMedicineProfile()
        {
            CreateMap<PrescriptionMedicine, MedicineDto>()
                .ForMember(dest => dest.Name, org => org.MapFrom(af => af.Name))
                .ForMember(dest => dest.Dosage, org => org.MapFrom(af => af.Dosage))
                .ForMember(dest => dest.Duration, org => org.MapFrom(af => af.Duration));

        }
    }
}
