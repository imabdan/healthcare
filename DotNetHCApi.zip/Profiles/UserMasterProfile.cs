﻿using AutoMapper;
using HealthCare.Dtos;
using HealthCare.Helpers;
using HealthCareAPI.Area.Common;

namespace HealthCare.Profiles
{
    public class UserMasterProfile : Profile
    {
        public UserMasterProfile()
        {
            CreateMap<UserMaster, UserMasterReadDto>()
                .ForMember(dest => dest.Name, opt => opt.MapFrom(org => $"{org.FirstName} {org.LastName}"))
                .ForMember(dest => dest.Age, opt => opt.MapFrom(org => org.DOB.GetCurrentAge()));
        }
    }
}
