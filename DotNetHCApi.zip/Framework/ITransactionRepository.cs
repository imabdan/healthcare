﻿using HealthCareAPI.Area.Common;
using HealthCareAPI.Area.Transaction;
using HealthCareAPI.Dtos;
using HealthCareAPI.Transactions;

namespace HealthCareAPI.Framework
{
    public interface IUserRepo : IBaseRepository<UserMaster>
    {
        //This follow LSP - Liskov Subs. Pri. and ISP - Interface segregation principal
        public Task<UserMaster> ValidateCredentialsAsync(string email, string password);
        public Task<bool> EmailDupCheck(string email);
        public Task<List<PhysicianDto>> GetPhysicians();
    }
    public interface IAppointmentRepo : IBaseRepository<Appointment>
    {
        /// <summary>
        /// Method to get the appointment list for the specific user or for a physician
        /// </summary>
        /// <param name="id"></param>
        /// <param name="role"></param>
        /// <returns></returns>
        public Task<List<veAppointment>> GetAllbyIdAsync (int id, string role);
        public Task<Prescription> SavePresAsync(PrescriptionCreateDto dto);
        public Task<List<PrescriptionMedicine>> GetPres(int prescId);
    }
}
