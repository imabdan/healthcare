﻿namespace HealthCareAPI.Framework
{
    /// <summary>
    /// Base repository, defined CRUD actions
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IBaseRepository<T> where T : class
    {
        /// <summary>
        /// Method to get list of entity
        /// </summary>
        /// <returns></returns>
        Task<List<T>> GetAllAsync();
        /// <summary>
        /// Method to get single record based on givem param
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task<T> GetbyIdAsync(int id);
        /// <summary>
        /// Method to create a resource
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        T Create(T entity);
        /// <summary>
        /// Method to update the resource
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        T Update(T entity);
        /// <summary>
        /// Method to delete specific resource by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        void Delete(int id);
    }
}
