﻿using HealthCareAPI.Framework;
using System.ComponentModel.DataAnnotations.Schema;

namespace HealthCareAPI.Transactions
{
    public class Prescription : TranAuditableBase
    {
        public int Id { get; set; }
        public int AppointmentId { get; set; }
        public int PatientId { get; set; }
        public string Symptoms { get; set; }
        public string Diagnosis { get; set; }
        public string Advice { get; set; }
        [Column(TypeName = "timestamp without time zone")]
        public DateTime? NextVisit { get; set; }
        // Navigation
        public List<PrescriptionMedicine> Medicines { get; set; }
    }

    public class PrescriptionCreateDto
    {
        public int AppointmentId { get; set; }
        public int PatientId { get; set; }
        public string Symptoms { get; set; }
        public string Diagnosis { get; set; }
        public string Advice { get; set; }
        public DateTime? NextVisit { get; set; }
        public List<MedicineDto> Medicines { get; set; }
    }

}
