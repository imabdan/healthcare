﻿using HealthCareAPI.Framework;

namespace HealthCareAPI.Transactions
{
    public class PrescriptionMedicine : TranAuditableBase
    {
        public int Id { get; set; }
        public int PrescriptionId { get; set; }
        public string Name { get; set; }
        public string Dosage { get; set; }
        public string Duration { get; set; }
        // Navigation
        public Prescription Prescription { get; set; }
    }

    public class MedicineDto
    {
        public string Name { get; set; }
        public string Dosage { get; set; }
        public string Duration { get; set; }
    }
}
