﻿using System.Runtime.Serialization;

namespace HealthCareAPI.AFBase
{
    /// <summary>
    /// To map active status as Active, Suspend, Blocked and Deleted
    /// </summary>
    public enum AFStatus
    {
        [EnumMember(Value = "A")]
        A, // Active
        [EnumMember(Value = "S")]
        S, // Suspended
        [EnumMember(Value = "B")]
        B, // Blocked
        [EnumMember(Value = "D")]
        D, // Deleted
    }
    /// <summary>
    /// To map roles, Physician, Patient, Admin and Nurse
    /// </summary>
    public enum Role
    {
        [EnumMember(Value = "Physician")]
        PH,
        [EnumMember(Value = "Patient")]
        PT,
        [EnumMember(Value = "Admin")]
        AD,
        [EnumMember(Value = "Nurse")]
        NS
    }
}
