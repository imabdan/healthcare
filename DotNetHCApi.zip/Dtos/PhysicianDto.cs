﻿namespace HealthCareAPI.Dtos
{
    public class PhysicianDto
    {
        public int UserMasterId { get; set; }
        public string Name { get; set; }
    }
}
