﻿namespace HealthCare.Dtos
{
    public class AuthorCreationDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB{ get; set; }
    }
}
