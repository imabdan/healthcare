import { AbstractControl, AsyncValidatorFn, FormGroup, ValidationErrors } from "@angular/forms";
import { catchError, map, Observable, of } from "rxjs";
import { UserService } from "../services/user.service";


export class CustomValidation {

  static duplicateEmailValidator(userService: UserService): AsyncValidatorFn {
  return (control: AbstractControl): Observable<ValidationErrors | null> => {
    const email = control.value;

    if (!email) {
      return of(null);
    }

    return userService.checkEmailExists(email).pipe(
      map(exists => exists ? { duplicateEmail: true } : null),
      catchError(() => of(null))
    );
  };
}

  // Mark only controls with validators
  static markValidationControls(form: FormGroup) {
    Object.keys(form.controls).forEach(key => {
      const control = form.get(key)!;

      // Only controls with validators
      const hasSyncValidator = !!control.validator;
      const hasAsyncValidator = !!control.asyncValidator;

      if (hasSyncValidator || hasAsyncValidator) {
        control.markAsTouched();
        control.markAsDirty();
        control.updateValueAndValidity();
      }
    });
 }
}
