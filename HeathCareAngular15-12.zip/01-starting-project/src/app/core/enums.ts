export enum Role {
  Admin = 'Admin',
  Physician = 'Physician',
  Nurse = 'Nurse',
  Patient = 'Patient'
}
export enum RoleValue {
  Admin = "AD",
  Physician = "PH",
  Nurse = "NS",
  Patient = "PT"
}
