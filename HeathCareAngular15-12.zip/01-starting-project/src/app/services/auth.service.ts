import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private api = 'https://localhost:44358/api/auth';
  accessToken: string | null = null;
  isLoggedIn = signal<boolean>(false);
  private http = inject(HttpClient);
  toastr = inject(ToastrService)

  constructor() {
    const loginFlag = sessionStorage.getItem('isLoggedIn');
    if (loginFlag === 'true') {
       this.isLoggedIn.set(true);
    }
    console.log(this.accessToken);
  }
  get token(): string | null {
    return this.accessToken;
  }

  login(email: string, password: string) {
    return this.http.post<any>(`${this.api}/login`, { email, password }, {withCredentials: true})
      .pipe(
        tap(res => {
          this.accessToken = res.token;
          console.log(this.accessToken);
          this.isLoggedIn.set(true);  // Initially false, will be set true on successful login
        })
      );
  }

  //This is used to load access token on app initialization or if we refresh browser manually.
  //Because in-memory access token will be lost on browser refresh.
  loadAccessTokenFromRefresh(): Observable<boolean> {
    console.log("Log from refresh");
    return this.http.post<any>(`${this.api}/refresh`, {}, { withCredentials: true })
      .pipe(
        tap(res =>{
          this.accessToken = res.token;
          this.isLoggedIn.set(!!res.token);
          console.log(this.accessToken);
        } ),
        map(() => true),
        catchError(() =>{
          this.isLoggedIn.set(false);
          return of(false)
        })
      );
  }

  refreshAccessToken(): Observable<string | null> {
    return this.http.post<any>(`${this.api}/refresh`, {}, { withCredentials: true })
      .pipe(
        tap(res => this.accessToken = res.token),
        map(res => res.token),
        catchError(() => of(null))
      );
  }

  getAccessToken() {
    return this.accessToken;
  }

  logout() {
    return this.http.post(`${this.api}/logout`, {}, { withCredentials: true })
      .pipe(
        tap(() => {
          this.isLoggedIn.set(false);
          sessionStorage.setItem('isLoggedIn', false.toString());
          localStorage.removeItem('user');
          this.accessToken = null
          window.location.href = '/login';
        })
      );
  }
}
