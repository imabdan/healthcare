import { HttpClient } from '@angular/common/http';
import { Injectable, inject, signal, DestroyRef, OnInit } from '@angular/core';
import { forkJoin, map, Observable } from 'rxjs';
import { UserMasterModel } from '../models/user-master.Model';
import { ToastrService } from 'ngx-toastr';
import { Role } from '../core/enums';
import { HistoryItem, User, AppointmentModel, MedicineDto } from '../models/user-vm';



@Injectable({
  providedIn: 'root'
})
export class UserService implements OnInit {

  //#region DEPENDENCY INJECTIONS AND OTHER INITIALIZATIONS
  private http = inject(HttpClient);
  private api = 'https://localhost:44358/api/';

  userDetails = signal<User | null>(null);
  allAppointment = signal<HistoryItem[]>([]);
  todaysAppointment = signal<HistoryItem[]>([]);
  upcomingAppointments = signal<HistoryItem[]>([]);
  upcomingAppointmentsForPhy = signal<HistoryItem[]>([]);
  pastAppointment = signal<HistoryItem[]>([]);
  toastr = inject(ToastrService);//this can be make global by creating a base service if needed
  private DestroyRef = inject(DestroyRef);
  role = signal('');;
  userId = '';
  constructor() {
    const user = localStorage.getItem('user');

    if (user) {
      const userObj = JSON.parse(user);
      this.userId = userObj.userMasterId;
      this.role.set(userObj.role);
    }
  }
  //#endregion


  ngOnInit(): void {

  }

  //#region  EMAIL CHECKER
  // Async validatr to check for duplicate email
  checkEmailExists(email: string): Observable<boolean> {
      return this.http
        .get<{ exists: boolean }>(`${this.api}user/check-email?email=${email}`, { withCredentials: true })
        .pipe(map(res => res.exists));
  }
  //#endregion

  //#region  USER REGISTRATION METHOD
  register(userData: UserMasterModel) {
    return this.http.post<UserMasterModel>(`${this.api}user/register`, userData, { withCredentials: true });
  }
  //#endregion

  //#region  DATA FETCHING METHODS
  //Method to get user details by ID
  getUserById(id: string): Observable<any> {
    return this.http.get<User>(`${this.api}user/${id}`);
  }

  //Method to get appointments by User ID
  getAppointmentsByUserId(): Observable<any[]> {
    return this.http.get<any[]>(`${this.api}appointment/${this.userId}/appointments?role=${this.role()}`, { withCredentials: true });
  }
  getAppointmentById(appointmentId: number): Observable<any> {
    return this.http.get<any>(`${this.api}appointment/${appointmentId}`, { withCredentials: true });
  }
  //#endregion

  //#region  DASHBOARD-DATA
  //Function to call multiple APIs to load dashboard data based on user role
  loadDashBoardData() {

    //This will be used for all roles
    const baseCalls = [
      this.getUserById(this.userId)
    ];

    let roleSpecificCalls = [];

    //Add role specific calls
    if(this.role() == Role.Patient || this.role() == Role.Physician){
      roleSpecificCalls.push(this.getAppointmentsByUserId());
    }

    //Add role specific calls to base calls to make a combined request
    if(roleSpecificCalls.length > 0){
      baseCalls.push(...roleSpecificCalls);
    }

    // Execute all calls in parallel
    const dashBoardSubs = forkJoin(baseCalls).subscribe({
      next : ([user, appointments]) => {
        this.userDetails.set(user);

        this.allAppointment.set(appointments);

       const today = new Date();
       const todayStr = today.toISOString().split('T')[0];

        const upcomingForPhy = appointments.filter((a : AppointmentModel) => a.appointmentDate > todayStr);
        const upcomingForPT = appointments.filter((a : AppointmentModel) => a.appointmentDate >= todayStr);
        const todays = appointments.filter((a : AppointmentModel) => a.appointmentDate === todayStr);
        const past = appointments.filter((a : AppointmentModel) => a.appointmentDate < todayStr);

        this.upcomingAppointmentsForPhy.set(upcomingForPhy);
        this.upcomingAppointments.set(upcomingForPT);
        this.todaysAppointment.set(todays);
        this.pastAppointment.set(past);
      },
      error : () =>{
        this.toastr.error('Failed to load dashboard data', 'Error');
      }
    });
    // Clean up subscription on destroy
    this.DestroyRef.onDestroy(() => {
      dashBoardSubs.unsubscribe();
    });
  }
  //#endregion

  //#region  FETCH PHYSICIANS
  getPhysicians(): Observable<any> {
    return this.http.get(`${this.api}user/physicians`, { withCredentials: true });
  }
  //#endregion

  //#region GET SELECTED PRESCRIPTION DETAILS
  getPrescription(id: number): Observable<MedicineDto[]> {
      return this.http.get<MedicineDto[]>(
        `${this.api}appointment/getPresc?prescId=${id}`
      );
  }
  //#endregion

}
