import { Component } from '@angular/core';

@Component({
  selector: 'app-internal-appointment-book',
  standalone: true,
  imports: [],
  templateUrl: './internal-appointment-book.component.html',
  styleUrl: './internal-appointment-book.component.css'
})
export class InternalAppointmentBookComponent {

}
