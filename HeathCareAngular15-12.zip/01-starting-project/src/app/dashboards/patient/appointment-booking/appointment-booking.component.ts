import { Component, inject, output, OnInit, DestroyRef } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomValidation } from '../../../core/custom-validation';
import { AppointmentModel } from '../../../models/user-vm';;
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-appointment-booking',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './appointment-booking.component.html',
  styleUrl: './appointment-booking.component.css'
})
export class AppointmentBookingComponent implements OnInit {

  //#region DEPENDENCY INJECTION USING SIGNAL
  private http = inject(HttpClient);
  private toastr = inject(ToastrService);
  private userService = inject(UserService);
  api = 'https://localhost:44358/api/appointment';
  private destroyRef = inject(DestroyRef);
  //#endregion

  //#region reactive form for appointment using FormBuilder
  appointmentForm = new FormBuilder().group({
    physicianId: ['', [Validators.required]],
    appointmentDate: ['', Validators.required],
    appointmentTime: ['',Validators.required],
    disease: [''],
    details: ['']
  });
  //#endregion

  isvalidFormSubmitted = true;
  //#region Another way to trasnmit event from child to parent component
  close = output<void>();
  closeModal() {
    this.close.emit();
  }
  //#endregion

  //#region SUBMIT FORM the appointment: add to history and close modal
  submitAppointment() {
    console.log("Appointment Model:", JSON.stringify(this.appointmentForm.value));
    //If valid, proceed else mark controls as touched to show validation errors
    if (this.appointmentForm.valid) {
      //Get form data and prepare model
      const model : AppointmentModel = this.appointmentForm.value as AppointmentModel;
      //Get user ID from local storage to set in model
      const userData = localStorage.getItem('user');
      if (userData) {
        const user = JSON.parse(userData);
        model.userMasterId = user.userMasterId;
      }
      model.appointmentTime = model.appointmentTime != "" ? model.appointmentTime + ":00" : ""; //append seconds to time
      console.log("Final Appointment Model:", JSON.stringify(model));
      //call API to save appointment
      this.http.post(this.api, model, {withCredentials: true})
      .subscribe({
        next: (response) => {
          this.toastr.success('Appointment booked successfully', 'Booking Confirmed');
        },
        error: (error) => {
          this.toastr.error('Error booking appointment', 'Booking Failed');
        }
      });
    }else{
      this.isvalidFormSubmitted = false;
      CustomValidation.markValidationControls(this.appointmentForm);
      return;
    }
    // auto-close and reset form
    this.closeModal();
    this.resetForm();
  }
  //#endregion

  resetForm() {
    this.appointmentForm.reset();
  }
  physicians: any[] = [];

  ngOnInit() {
    //To fetch physicians for dropdown
    const obs = this.userService.getPhysicians().subscribe(res => {
      this.physicians = res;
      console.log("Physician Source:", JSON.stringify(this.physicians));
    });
    // Clean up subscription on destroy
    this.destroyRef.onDestroy(() => {
      obs.unsubscribe();
    });
  }
}
