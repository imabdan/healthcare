import { Component } from '@angular/core';

@Component({
  selector: 'app-patient-history',
  standalone: true,
  imports: [],
  templateUrl: './patient-history.component.html',
  styleUrl: './patient-history.component.css'
})
export class PatientHistoryComponent {

}
