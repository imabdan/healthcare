import { Component, OnInit, signal, inject, effect, DestroyRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { AppointmentBookingComponent } from "../appointment-booking/appointment-booking.component";
import { HistoryItem,MedicineDto } from '../../../models/user-vm';

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, AppointmentBookingComponent],
  templateUrl: './patient-dashboard.component.html',
  styleUrls: ['./patient-dashboard.component.css']
})
export class PatientDashboardComponent implements OnInit {

  private userService = inject(UserService);
  private destroyRef = inject(DestroyRef)
  patient = signal(this.userService.userDetails());
  histories = signal<HistoryItem[]>([]);
  upcomingAppointments = signal<HistoryItem[]>([]);

  // Prescription popup signals
  showPrescription = signal<boolean>(false);
  selectedPrescription = signal<HistoryItem | null>(null);
  prescriptionMedicine = signal<MedicineDto[]>([]);

  isModalOpen = signal<boolean>(false);

  constructor() {
    effect(() => {
      this.patient.set(this.userService.userDetails());
      this.histories.set(this.userService.pastAppointment());
      this.upcomingAppointments.set(this.userService.upcomingAppointments());
    }, { allowSignalWrites: true });
  }

  ngOnInit(): void {
    this.userService.loadDashBoardData();
  }

  openModal() {
    this.isModalOpen.set(true);
  }
  closeModal() {
    this.isModalOpen.set(false);
  }

  // Prescription actions
  openPrescription(item: HistoryItem) {
    this.prescriptionMedicine.set([]);
    this.selectedPrescription.set(item);
    this.showPrescription.set(true);
    var presSubs = this.userService.getPrescription(item.appointmentId).subscribe({
      next: (pres: MedicineDto[]) => {
        this.prescriptionMedicine.set(pres);
      },
      error : (err) =>{
        console.error('Failed to load prescription', err);
        this.prescriptionMedicine.set([]);
      }
    })

    this.destroyRef.onDestroy(() => {
      presSubs.unsubscribe();
    })
  }

  closePrescription() {
    this.showPrescription.set(false);
    this.selectedPrescription.set(null);
  }
}
