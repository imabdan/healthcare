import { DatePipe } from '@angular/common';
import { Component, signal, inject, effect } from '@angular/core';
import { RouterLink } from "@angular/router";
import { HistoryItem } from '../../../models/user-vm';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-physician-dashboard',
  standalone: true,
  imports: [DatePipe, RouterLink],
  templateUrl: './physician-dashboard.component.html',
  styleUrl: './physician-dashboard.component.css'
})
export class PhysicianDashboardComponent {

  // DEPENDENCY INJECTIONS AND OTHER INITIALIZATIONS
  private userService = inject(UserService);
  doctor = signal(this.userService.userDetails());
  todayAppointments = signal<HistoryItem[]>([]);
  upcomingAppointments = signal<HistoryItem[]>([]);
  //#endregion

  today = new Date();

    // ------------ Doctor Profile ------------
    // doctor = {
    //   fullName: "Dr. Arjun Mehta",
    //   speciality: "General Physician",
    //   experience: 8,
    //   shiftTiming: "9:00 AM - 5:00 PM",
    // };

    // ------------ Stats ------------
    stats = signal({
      todayCount: 0,
      completed: 0,
      upcoming: 0,
      cancelled: 0
    });

    // ------------ Notifications ------------
    notifications = [
      { text: "New appointment booked by Riya", time: "2m ago" },
      { text: "Prescription added for Aakash", time: "20m ago" },
      { text: "Shift update: Tomorrow starts at 10 AM", time: "1h ago" }
    ];

    constructor() {
      effect(() => {
        this.doctor.set(this.userService.userDetails());
        this.todayAppointments.set(this.userService.todaysAppointment());
        this.upcomingAppointments.set(this.userService.upcomingAppointmentsForPhy());

        this.stats.set({
          todayCount: this.userService.todaysAppointment().length,
          upcoming: this.userService.upcomingAppointmentsForPhy().length,
          completed: this.userService.pastAppointment().length,
          cancelled: 0 // Add logic here if you have cancelled appointments
        });
      }, { allowSignalWrites: true });
    }

    ngOnInit(): void {
      this.userService.loadDashBoardData();
    }

    // 🔹 You can later convert these into real API calls
    /*
    loadTodayAppointments() {
        this.dashboardService.getTodayAppointments().subscribe(res => {
            this.todayAppointments = res;
        });
    }
    */
}
