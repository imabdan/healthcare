import { Component } from '@angular/core';

@Component({
  selector: 'app-patients-history',
  standalone: true,
  imports: [],
  templateUrl: './patients-history.component.html',
  styleUrl: './patients-history.component.css'
})
export class PatientsHistoryComponent {

}
