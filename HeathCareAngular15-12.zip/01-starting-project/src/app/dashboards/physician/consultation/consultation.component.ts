import { Component, DestroyRef, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, FormArray, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../../../services/user.service';
import { User } from '../../../models/user-vm';

@Component({
  selector: 'app-consultation',
  templateUrl: './consultation.component.html',
  styleUrls: ['./consultation.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class ConsultationComponent implements OnInit {

  private http = inject(HttpClient);
  private userService = inject(UserService);
  private destroyRef = inject(DestroyRef);
  appointmentId!: number;
  consultationForm!: FormGroup;
  private api = 'https://localhost:44358/api/';

  patient = signal<any>({
    name: "",
    age: 0,
    gender: "",
    bloodGroup: "",
    phone: "",
    lastVisit: "",
    allergies: "",
    history: [
      "Fever (Aug 2025)",
      "Back Pain (Mar 2025)"
    ]
  });

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router
  ) {}

  ngOnInit(): void {
     this.appointmentId = Number(this.route.snapshot.paramMap.get('appointmentId'));


  //Loading current appointment so it shud not get reset signal values
  this.userService.getAppointmentById(this.appointmentId).subscribe({
    next: appt => {
      const patientId = appt.userMasterId;
      //Now fetching the current patient detail
      this.userService.getUserById(patientId).subscribe({
        next: (res: User) => {
          this.patient.set({
            name: res.name,
            age: res.age,
            gender: res.gender,
            bloodGroup: res.bloodGroup,
            phone: res.phoneNumber,
            history: []
          });
        }
      });

      //Load patient history fresh
      this.userService.getAppointmentsByUserId()
        .subscribe(history => {
          const pastHistory = history
            .filter(h => h.appointmentDate < new Date().toISOString().split('T')[0])
            .map(h => `${h.disease} (${h.appointmentDate})`);

          this.patient.update(prev => ({
            ...prev,
            history: pastHistory
          }));

        });
    }
  });

    this.consultationForm = this.fb.group({
      appointmentId: this.appointmentId,
      patientId: 1,
      symptoms: [''],
      diagnosis: [''],
      advice: [''],
      nextVisit: [''],
      medicines: this.fb.array([])
    });
    // Add a row for medicine by default
    this.addMedicine();
  }

  get medicines(): FormArray<FormGroup> {
    return this.consultationForm.get('medicines') as any;
  }

  addMedicine() {
    const med = this.fb.group({
      name: [''],
      dosage: [''],
      duration: ['']
    });
    this.medicines.push(med);
  }

  removeMedicine(i: number) {
    this.medicines.removeAt(i);
  }

  saveConsultation() {
    console.log(this.consultationForm.value);
    var saveSubs = this.http.post(`${this.api}appointment/savePresc`, this.consultationForm.value, {withCredentials: true})
        .subscribe({
          next: (res: any) => {
            alert(res.message);
            this.router.navigate(['/physician-dashboard']);
          },
          error: err => {
            console.error(err);
          }
    });
    this.destroyRef.onDestroy( () => {
      saveSubs.unsubscribe();
    })

    this.router.navigate(['/physician-dashboard']);
  }

  goBack() {
    this.router.navigate(['/physician-dashboard']);
  }
}
