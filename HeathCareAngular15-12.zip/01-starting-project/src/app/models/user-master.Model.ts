export class UserMasterModel {
  email!: string;
  password!: string;
  confirmPassword!: string;
  firstName!: string;
  lastName!: string;
  dob!: Date;
  phoneNumber!: string;
  emergencyContact!: string;
  gender!: string;
  address!: string;
  state!: string;
  country!: string;
  zipCode!: string;
  terms!: boolean;
}


