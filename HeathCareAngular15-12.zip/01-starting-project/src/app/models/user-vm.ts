export interface User {
  name: string;
  specialization : string;
  age: number;
  bloodGroup: string;
  gender: 'Male' | 'Female' | 'Other';
  phoneNumber: string;
}

export interface HistoryItem {
  appointmentId : number;
  userMasterId: string;
  physicianName: string;
  patientName: string;
  appointmentDate: string;
  appointmentTime: string;
  reason: string;
  disease?: string;
  details?: string;
}
export interface AppointmentModel {
  appointmentId: number;
  userMasterId: string;
  physicianId: string;
  appointmentDate: string;
  appointmentTime : string;
  reason: string;
  disease: string;
  details: string;
  status: string;
}

export interface MedicineDto{
  name : string,
  dosage : string,
  duration : string
}
