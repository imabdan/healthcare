import { Component, DestroyRef, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink,DatePipe],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  private auth = inject(AuthService);
  showProfile = false;
  name = signal<string>('');
  currentDateTime = signal<Date>(new Date());
  private destroyRef = inject(DestroyRef);

  onProfileClick() {
    this.showProfile = !this.showProfile;
  }
  logout() {
    const logOutSubs = this.auth.logout().subscribe();
    this.destroyRef.onDestroy(() =>
      logOutSubs.unsubscribe()
    );
  }

  ngOnInit() {
    const userData = localStorage.getItem('user');
    if (userData) {
      const user = JSON.parse(userData);
      this.name.set(user.name);
    }
    setInterval(() => {
      this.currentDateTime.set(new Date());
    }, 1000)
  }

}

