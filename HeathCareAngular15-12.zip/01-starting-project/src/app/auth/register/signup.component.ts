import { RoleValue } from './../../core/enums';
import { Component, inject, OnInit, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserMasterModel } from '../../models/user-master.Model';
import { AuthService } from '../../services/auth.service';
import { CustomValidation } from '../../core/custom-validation';
import { UserService } from '../../services/user.service';
//Must include uppercase, lowercase, number, special char and 6 digit,
const strongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#.^()\-_=+])[A-Za-z\d@$!%*?&#.^()\-_=+]{6,}$/;



@Component({
  selector: 'app-signup',
  standalone: true,
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
  imports: [ReactiveFormsModule]
})
export class SignupComponent implements  OnInit {

  //#region DEPENDENCIES
  private userService = inject(UserService);
  private authService = inject(AuthService);
  Role = RoleValue;
  //#endregion

  //#region  FORM GROUP WITH CONTROLS
  form = new FormGroup({
    email: new FormControl<string>('',{
      validators: [Validators.required, Validators.email],
      asyncValidators: [CustomValidation.duplicateEmailValidator(this.userService)],//To check duplicate email by calling api
      updateOn: 'blur'//Will get troggered when we click outside
    }),
    password: new FormControl<string>('',{
      validators: [Validators.required, Validators.minLength(6), Validators.pattern(strongPassword)]
    }),
    confirmPassword: new FormControl<string>('', {validators: [Validators.required]}),
    firstName: new FormControl<string>('',{validators : [Validators.required]}),
    lastName: new FormControl<string>('',{validators : [Validators.required]}),
    dob : new FormControl<Date | null>(null, {validators: [Validators.required]}),
    phoneNumber: new FormControl<string>('',{
      validators: [Validators.required, Validators.pattern(/^\+?[1-9]\d{1,14}$/)]
    }),
    emergencyContact: new FormControl<string>(''),
    gender: new FormControl<'Male' | 'Female' | 'Other'>('Male'),
    address: new FormControl<string>('',{validators: [Validators.required]}),
    state: new FormControl<string>('',{validators: [Validators.required]}),
    country: new FormControl<string>('',{validators: [Validators.required]}),
    postalCode: new FormControl<string>('', {validators: [Validators.required]}),
    role : new FormControl<string>('', {validators: [Validators.required]}),
    specialization : new FormControl<string>(''),
    bloodGroup : new FormControl<string>(''),
    terms: new FormControl<boolean>(false, {validators: [Validators.requiredTrue]})
 });

  ngOnInit() {
    //Loading saved form data from local storage to populate accordingly
    const savedForm = localStorage.getItem('signupForm');
    if (savedForm) {
      this.form.setValue(JSON.parse(savedForm));
    }
  }
  //For invalid password validation
  get invalidPassword(){
    const passwordControl = this.form.controls.password;
    return passwordControl.invalid && (passwordControl.dirty || passwordControl.touched);
  }
  get invalidCnfPswd(){
    const confirmPassword = this.form.controls.confirmPassword;
    return confirmPassword.invalid && (confirmPassword.dirty || confirmPassword.touched);
  }
 //check password matching
  get passwordNotMatching(){
    const password = this.form.controls.password.value;
    const confirmPassword = this.form.controls.confirmPassword.value;
    return password !== confirmPassword && this.form.controls.confirmPassword.touched && this.form.controls.confirmPassword.dirty;
  }
  //Getting current role to show and hide fields based on role
  get currentRole(){
    return this.form.controls.role.value;
  }
  isValidForm = signal(true);
  onSubmit() {
    console.log('Form submitted:', this.form);
    const model: UserMasterModel = this.form.value as UserMasterModel;
    model.password, model.confirmPassword, model.email = '';  // password can be excluded for security reasons
    localStorage.setItem('signupForm', JSON.stringify(model));// to auto fill user info if refreshed
    if(this.form.valid){
      this.userService.register(model).subscribe({
        next: () => {
          this.authService.toastr.success('Registration successful', "Success");
          this.form.reset();
          window.location.href = '/login';
          localStorage.removeItem('signupForm');// clear saved form data
        },
        error: (err) => {
          this.authService.toastr.error('Registration failed:', "Error");
          console.error('Registration error:', err);
        }
      });
    }else{
      this.isValidForm.set(false);
      // Mark only validation controls
      CustomValidation.markValidationControls(this.form);
    }
  }
}
