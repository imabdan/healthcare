import { Component, DestroyRef, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomValidation } from '../../core/custom-validation';
import { Role } from '../../core/enums';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  imports: [RouterLink, ReactiveFormsModule]
})
export class LoginComponent {
  private authService = inject(AuthService);
  private router = inject(Router);
  private destroyRef = inject(DestroyRef);
  form = new FormGroup({
   email : new FormControl('', { validators: [Validators.required, Validators.email]}),
   password : new FormControl('', { validators: [Validators.required, Validators.minLength(6)]})
  });

  //To call login auth api for user validation and token creation
  onLogin() {
    //If form valid, processing login logic
    if(this.form.valid){
      const email = this.form.value.email??'';
      const password = this.form.value.password??'';

      const observalbel = this.authService.login(email, password).subscribe({
          next: (res) => {
            const role = res.user.role;
            //Based on logged in user getting roles and navigating accordingly
            switch (role) {
              case Role.Patient: this.router.navigate(['/patient-dashboard']); break;
              case Role.Physician: this.router.navigate(['/physician-dashboard']); break;
              case Role.Nurse: this.router.navigate(['/nurse-dashboard']); break;
              case Role.Admin: this.router.navigate(['/admin-dashboard']); break;
              default: this.authService.toastr.error('Unknown role', "Login Error");
            }
            this.authService.toastr.success('Login successful', "Welcome!");
            // Store user info
            localStorage.setItem('user', JSON.stringify(res.user));// to show user info on dashboard
            sessionStorage.setItem('isLoggedIn', true.toString());//to keep login state on browser refresh
          },
          error: () => this.authService.toastr.error('Invalid credentials', "Login Error")
        });

        // Clean up subscription on destroy
        this.destroyRef.onDestroy(() => observalbel.unsubscribe());
      }
      else{
        //Mark mandatory fields touched and show the alert
        CustomValidation.markValidationControls(this.form);
      }
    }

  }
