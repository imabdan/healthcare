import { Routes } from "@angular/router";
import { authGuard } from "./core/auth.guard";

export const routes : Routes = [
    // Public routes first, for this route guard is not required
    {
      path: 'login',
      loadComponent: () =>
        import('./auth/login/login.component').then(m => m.LoginComponent)
    },
    {
      path : 'signup',
      loadComponent : () =>
        import('./auth/register/signup.component').then(m => m.SignupComponent)
    },

    {
      path: 'admin-dashboard',
      canActivate : [authGuard],
      loadComponent: () =>
        import('./dashboards/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent)
    },
    {
      path : 'nurse-dashboard',
      canActivate : [authGuard],
      loadComponent : () =>
        import('./dashboards/nurse/nurse-dashboard/nurse-dashboard.component').then(m => m.NurseDashboardComponent)
    },
    {
      path : 'physician-dashboard',
      canActivate : [authGuard],
      loadComponent : () =>
        import('./dashboards/physician/physician-dashboard/physician-dashboard.component').then(m => m.PhysicianDashboardComponent)
    },
    {
      path : 'patient-dashboard',
      canActivate : [authGuard],
      loadComponent : () =>
        import('./dashboards/patient/patient-dashboard/patient-dashboard.component').then(m => m.PatientDashboardComponent)
    },
    {
      path : "consultation/:appointmentId",
      canActivate : [authGuard],
      loadComponent : () =>
        import('./dashboards/physician/consultation/consultation.component').then(m => m.ConsultationComponent)
    }
      ,
    { path: '**', redirectTo: 'login' }//If url not found redirect to login

];
