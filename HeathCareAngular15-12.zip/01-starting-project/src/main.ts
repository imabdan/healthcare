import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { provideHttpClient, withInterceptorsFromDi, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, importProvidersFrom } from '@angular/core';
import { TokenInterceptor } from './app/interceptors/auth.interceptor';
import { AuthService } from './app/services/auth.service';
import { provideRouter, withRouterConfig } from '@angular/router';
import { routes } from './app/app.routes';
import { BrowserAnimationsModule, provideAnimations } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';


// Load access token from refresh cookie before app starts
export function initApp(auth: AuthService) {
  return () => auth.loadAccessTokenFromRefresh().toPromise();
}

bootstrapApplication(AppComponent, {


  providers: [
    ...(appConfig.providers ?? []),//app.routes.ts for navigations to different component

    provideRouter(routes, withRouterConfig({
      onSameUrlNavigation: 'reload'
    })),

    //For Angular Animations
    provideAnimations(),

    // Register Toastr
    importProvidersFrom(
      BrowserAnimationsModule,
      ToastrModule.forRoot({
        timeOut: 3000,
        positionClass: 'toast-top-right',
        preventDuplicates: true
      })
    ),
    //Runs before Angular initializes UI
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      deps: [AuthService],
      multi: true
    },

    // Register the class-based interceptor in DI so withInterceptorsFromDi can pick it up
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },

    // Provide HttpClient configured to use interceptors from DI
    provideHttpClient(
      withInterceptorsFromDi()
    )
  ]
})
.catch(err => console.error(err));
