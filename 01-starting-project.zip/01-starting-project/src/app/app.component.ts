import { Component , effect, inject} from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './services/auth.service';


@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  imports: [RouterOutlet, HeaderComponent],
})
export class AppComponent {
  private authService = inject(AuthService);
  //isLoggedIn = false;
  isLoggedIn = this.authService.isLoggedIn();

  constructor(){
    effect(() => {
      this.isLoggedIn = this.authService.isLoggedIn();
    });
  }
}
