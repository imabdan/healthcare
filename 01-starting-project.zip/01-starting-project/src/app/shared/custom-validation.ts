import { inject } from "@angular/core";
import { AbstractControl, FormGroup } from "@angular/forms";
import { of } from "rxjs";
import { AuthService } from "../services/auth.service";

//check duplicate email note : this can be outsourced to a separate file
export class CustomValidation {

    private auth = inject(AuthService)
    static duplicateEmailValidator(control : AbstractControl) {
        if (!control.value) 
            return of(null);
    
        // Need to call the backend to check for duplicate email
        if (control.value === 'patient@gmail.com') {
          return of({ duplicateEmail: true });
        }
        return of(null);
    };
    // Mark only controls with validators
  static markValidationControls(form: FormGroup) {
    Object.keys(form.controls).forEach(key => {
      const control = form.get(key)!;

      // Only controls with validators
      const hasSyncValidator = !!control.validator;
      const hasAsyncValidator = !!control.asyncValidator;

      if (hasSyncValidator || hasAsyncValidator) {
        control.markAsTouched();
        control.markAsDirty();
        control.updateValueAndValidity();
      }
    });
 }
}
