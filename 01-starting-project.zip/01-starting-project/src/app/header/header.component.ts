import { Component, inject, Inject, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit {
  private auth = inject(AuthService);
  showProfile = false;
  role = this.auth.role;

  onProfileClick() {
    this.showProfile = !this.showProfile;
  }
  logout() {
    this.auth.role.set('');
    this.auth.isLoggedIn.set(false);
    // You can clear tokens here later
    window.location.href = '/login';
  }

  ngOnInit() {
    const userData = localStorage.getItem('user');
    if (userData) {
      const user = JSON.parse(userData);
      this.auth.role.set(user.role);
    }
  }
}
