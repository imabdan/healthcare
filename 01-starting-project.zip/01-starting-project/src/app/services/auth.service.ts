import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { AuthResponse } from '../models/auth-response';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private api = 'https://localhost:44358/api/auth'; //for now I kept localhost
  accessToken: string | null = null;
  isLoggedIn = signal<boolean>(false);
  role = signal<string>('');
  private http = inject(HttpClient);

  get token(): string | null {
    return this.accessToken;
  }

  login(email: string, password: string) {
    console.log('AuthService login called');
    return this.http.post<any>(`${this.api}/login`, { email, password })
      .pipe(
        tap(res => {
          this.accessToken = res.token;
        })
      );
  }
  
  //This is used to load access token on app initialization or if we refresh browser manually.
  //Because in-memory access token will be lost on browser refresh.
  loadAccessTokenFromRefresh(): Observable<boolean> {
    return this.http.post<any>(`${this.api}/refresh`, {}, { withCredentials: true })
      .pipe(
        tap(res => this.accessToken = res.token),
        map(() => true),
        catchError(() => of(false))
      );
  }

  refreshAccessToken(): Observable<string | null> {
    return this.http.post<any>(`${this.api}/refresh`, {}, { withCredentials: true })
      .pipe(
        tap(res => this.accessToken = res.token),
        map(res => res.token),
        catchError(() => of(null))
      );
  }

  getAccessToken() {
    return this.accessToken;
  }

  logout() {
    return this.http.post(`${this.api}/logout`, {}, { withCredentials: true })
      .pipe(
        tap(() => this.accessToken = null)
      );
  }
}
