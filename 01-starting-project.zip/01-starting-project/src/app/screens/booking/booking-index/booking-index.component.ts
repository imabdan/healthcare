import { Component } from '@angular/core';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-booking-index',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './booking-index.component.html',
  styleUrl: './booking-index.component.css'
})
export class BookingIndexComponent {

}
