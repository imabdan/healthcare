import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from "@angular/router";

@Component({
  selector: 'app-booking-details',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './booking-details.component.html',
  styleUrl: './booking-details.component.css'
})
export class BookingDetailsComponent {

  form = new FormGroup({
    bookingId : new FormControl('', {
      validators : [Validators.required, Validators.minLength(3), Validators.maxLength(10)]
    }),
    salesPerson : new FormControl('',{ validators : [Validators.required]}),
    customerName : new FormControl('',{ validators : [Validators.required]}),
    customerAddress : new FormControl('',{ validators : [Validators.required]}),
    hblno : new FormControl(''),
    mblno : new FormControl('',{ validators : [Validators.required]}),
    poo : new FormControl('',{ validators : [Validators.required]}),
    pol : new FormControl('',{ validators : [Validators.required]}),
    pod : new FormControl('',{ validators : [Validators.required]}),
    fpod : new FormControl('',{ validators : [Validators.required]}),
    carrier : new FormControl(''),
    etd : new FormControl('',{ validators : [Validators.required]}),
    eta : new FormControl(''),
    vesselName : new FormControl('',{ validators : [Validators.required]}),
    voyageNumber : new FormControl('',{ validators : [Validators.required]}),
  })

  onSubmit(){
    console.log(this.form);
    console.log(this.form.value);
    console.log(this.form.value.bookingId);
  }
}
