import { BehaviorSubject, catchError, Observable, switchMap, throwError } from "rxjs";
import { AuthService } from "../services/auth.service";
import { Injectable } from "@angular/core";
import { HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  private isRefreshing = false;
  private refreshSubject = new BehaviorSubject<string | null>(null);

  constructor(private auth: AuthService) {}

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {

    const token = this.auth.accessToken;

    // attach access token
    let authReq = req;
    if (token) {
      authReq = req.clone({
        setHeaders: { Authorization: `Bearer ${token}` }
      });
    }

    return next.handle(authReq).pipe(
      catchError(error => {

        //If unautohorized 401, token expired then call refresh
        if (error.status === 401 && !this.isRefreshing) {
          this.isRefreshing = true;
          this.refreshSubject.next(null);

          return this.auth.refreshAccessToken().pipe(
            switchMap(newToken => {
              this.isRefreshing = false;

              if (newToken) {
                this.refreshSubject.next(newToken);

                // Retry original request with new token
                return next.handle(
                  req.clone({
                    setHeaders: { Authorization: `Bearer ${newToken}` }
                  })
                );
              }

              return throwError(() => error);
            })
          );
        }

        return throwError(() => error);
      })
    );
  }
}
