import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CustomValidation } from '../../../shared/custom-validation';

interface Patient {
  name: string;
  age: number;
  bloodGroup: string;
  gender: 'Male' | 'Female' | 'Other';
}

interface HistoryItem {
  physician: string;
  appointmentDate: string; // ISO date (YYYY-MM-DD)
  appointmentTime: string; // HH:mm
  disease?: string;
  details?: string;
}

@Component({
  selector: 'app-patient-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './patient-dashboard.component.html',
  styleUrls: ['./patient-dashboard.component.css']
})
export class PatientDashboardComponent {
  // example patient; in real app you would fetch this
  patient = signal<Patient>({
    name: 'Aadil Abdan',
    age: 30,
    bloodGroup: 'B+',
    gender: 'Male'
  });

  // Past history (initial example entries)
  history = signal<HistoryItem[]>([
    {
      physician: 'Dr. Rao',
      appointmentDate: '2025-09-15',
      appointmentTime: '10:30',
      disease: 'Flu',
      details: 'Prescribed rest and paracetamol'
    },
    {
      physician: 'Dr. Mehta',
      appointmentDate: '2024-12-05',
      appointmentTime: '14:00',
      disease: 'Allergy',
      details: 'Allergy tests recommended'
    }
  ]);

  // modal open state as a signal
  isModalOpen = signal(false);

  // reactive form for appointment
  appointmentForm = new FormBuilder().group({
    physician: ['', [Validators.required, Validators.minLength(2)]],
    appointmentDate: ['', Validators.required], // yyyy-mm-dd
    appointmentTime: ['', Validators.required], // hh:mm
    disease: ['', Validators.required],
    details: ['']
  });

  // open/close modal
  openModal() {
    this.isModalOpen.set(true);
    this.resetForm(); // clear previous values on open
  }

  closeModal() {
    this.isModalOpen.set(false);
  }

  resetForm() {
    this.appointmentForm.reset();
  }

  // Submit the appointment: add to history and close modal
  submitAppointment() {
    console.log(this.appointmentForm.value);
    if (this.appointmentForm.invalid) {
      CustomValidation.markValidationControls(this.appointmentForm);
      return;
    }

    const value = this.appointmentForm.value as HistoryItem;

    // add new history item at start (most recent first)
    this.history.set([value, ...this.history()]);

    // auto-close and reset form
    this.closeModal();
    this.resetForm();
  }

  // utility getter for template
  get histories() {
    return this.history();
  }
}
