import { Component } from '@angular/core';

@Component({
  selector: 'app-appointment-booking',
  standalone: true,
  imports: [],
  templateUrl: './appointment-booking.component.html',
  styleUrl: './appointment-booking.component.css'
})
export class AppointmentBookingComponent {

}
