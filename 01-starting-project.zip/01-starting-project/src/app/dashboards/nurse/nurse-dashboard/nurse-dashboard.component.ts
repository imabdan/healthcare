import { Component } from '@angular/core';

@Component({
  selector: 'app-nurse-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './nurse-dashboard.component.html',
  styleUrl: './nurse-dashboard.component.css'
})
export class NurseDashboardComponent {

}
