import { Component } from '@angular/core';

@Component({
  selector: 'app-physician-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './physician-dashboard.component.html',
  styleUrl: './physician-dashboard.component.css'
})
export class PhysicianDashboardComponent {

}
