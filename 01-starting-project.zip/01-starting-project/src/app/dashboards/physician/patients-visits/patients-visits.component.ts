import { Component } from '@angular/core';

@Component({
  selector: 'app-patients-visits',
  standalone: true,
  imports: [],
  templateUrl: './patients-visits.component.html',
  styleUrl: './patients-visits.component.css'
})
export class PatientsVisitsComponent {

}
