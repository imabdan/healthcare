import { Component, DestroyRef, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomValidation } from '../../shared/custom-validation';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  imports: [RouterLink, ReactiveFormsModule]
})
export class LoginComponent {
  private authService = inject(AuthService);
  private router = inject(Router);
  private destroyRef = inject(DestroyRef);
  form = new FormGroup({
   email : new FormControl('', { validators: [Validators.required, Validators.email]}),
   password : new FormControl('', { validators: [Validators.required, Validators.minLength(6)]})
  });
  
  onLogin() {
    if(this.form.valid){
      const email = this.form.value.email??'';
      const password = this.form.value.password??'';

      const observalbel = this.authService.login(email, password).subscribe({
          next: (res) => {
            const role = res.user.role;
            switch (role) {
              case 'patient': this.router.navigate(['/patient-dashboard']); break;
              case 'physician': this.router.navigate(['/physician-dashboard']); break;
              case 'nurse': this.router.navigate(['/nurse-dashboard']); break;
              default: alert('Unknown role');
            }
            // Store safe user info
            localStorage.setItem('user', JSON.stringify(res.user));
          },
          error: () => alert('Invalid credentials')
        });

        // Clean up subscription on destroy
        this.destroyRef.onDestroy(() => observalbel.unsubscribe());
      }
      else{
        CustomValidation.markValidationControls(this.form);
      }
    }
    
  }
