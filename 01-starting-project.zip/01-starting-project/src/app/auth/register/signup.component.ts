import { Component, inject, OnInit, signal } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, ValidationErrors, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserMasterModel } from '../../models/user-master.Model';
import { AuthService } from '../../services/auth.service';
import { of } from 'rxjs';
import { CustomValidation } from '../../shared/custom-validation';
const strongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#.^()\-_=+])[A-Za-z\d@$!%*?&#.^()\-_=+]{6,}$/;



@Component({
  selector: 'app-signup',
  standalone: true,
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
  imports: [ReactiveFormsModule]
})
export class SignupComponent implements  OnInit {

  private authService = inject(AuthService);

  form = new FormGroup({
    email: new FormControl<string>('',{
      validators: [Validators.required, Validators.email],
      asyncValidators: [CustomValidation.duplicateEmailValidator],
      updateOn: 'blur'
    }),
    password: new FormControl<string>('',{
      validators: [Validators.required, Validators.minLength(6), Validators.pattern(strongPassword)]
    }),
    confirmPassword: new FormControl<string>('', {validators: [Validators.required]}),
    firstName: new FormControl<string>('',{validators : [Validators.required]}),
    lastName: new FormControl<string>('',{validators : [Validators.required]}),
    dob : new FormControl<Date | null>(null, {validators: [Validators.required]}),
    phoneNumber: new FormControl<string>('',{
      validators: [Validators.required, Validators.pattern(/^\+?[1-9]\d{1,14}$/)]
    }),
    emergencyContact: new FormControl<string>(''),
    gender: new FormControl<'Male' | 'Female' | 'Other'>('Male'),
    address: new FormControl<string>('',{validators: [Validators.required]}),
    state: new FormControl<string>('',{validators: [Validators.required]}),
    country: new FormControl<string>('',{validators: [Validators.required]}),
    postalCode: new FormControl<string>('', {validators: [Validators.required]}),
    role : new FormControl<string>('patient', {validators: [Validators.required]}),
    bloodGroup : new FormControl<string>('', {validators: [Validators.required]}),
    terms: new FormControl<boolean>(false, {validators: [Validators.requiredTrue]})
 });

  ngOnInit() {

  }
  get invalidPassword(){
    const passwordControl = this.form.controls.password;
    return passwordControl.invalid && (passwordControl.dirty || passwordControl.touched);
  }
  get invalidCnfPswd(){
    const confirmPassword = this.form.controls.confirmPassword;
    return confirmPassword.invalid && (confirmPassword.dirty || confirmPassword.touched);
  }
 //check password matching
  get passwordNotMatching(){
    const password = this.form.controls.password.value;
    const confirmPassword = this.form.controls.confirmPassword.value;
    return password !== confirmPassword && this.form.controls.confirmPassword.touched && this.form.controls.confirmPassword.dirty;
  }
  isValidForm = signal(true);
  onSubmit() {
    if(this.form.valid){
      const model: UserMasterModel = this.form.value as UserMasterModel;
      //this.authService.register(model)
    }else{
      this.isValidForm.set(false);
      console.log(this.form);
      // Mark only validation controls
      CustomValidation.markValidationControls(this.form);
    }
  }

  
}
