export interface AuthResponse {
  token: string;
  user: {
    userId: number;
    email: string;
    role?: string;
    name ?: string;
  };
}
