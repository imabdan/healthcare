import { Routes } from "@angular/router";
import { LoginComponent } from "./auth/login/login.component";
import { SignupComponent } from "./auth/register/signup.component";
import { PhysicianDashboardComponent } from "./dashboards/physician/physician-dashboard/physician-dashboard.component";
import { NurseDashboardComponent } from "./dashboards/nurse/nurse-dashboard/nurse-dashboard.component";
import { PatientDashboardComponent } from "./dashboards/patient/patient-dashboard/patient-dashboard.component";
import { HeaderComponent } from "./header/header.component";

export const routes : Routes = [
    { path: '', component: LoginComponent },
    { path: 'login', component: LoginComponent },
    { path: 'signup',component: SignupComponent },
    { path: 'patient-dashboard', component: PatientDashboardComponent },
    { path: 'physician-dashboard', component: PhysicianDashboardComponent },
    { path: 'nurse-dashboard', component: NurseDashboardComponent },
    //{ path: '**', redirectTo: 'login' }
    
];