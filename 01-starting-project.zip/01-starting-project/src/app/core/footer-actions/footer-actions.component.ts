import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-actions',
  standalone: true,
  imports: [],
  templateUrl: './footer-actions.component.html',
  styleUrl: './footer-actions.component.css'
})
export class FooterActionsComponent {

}
